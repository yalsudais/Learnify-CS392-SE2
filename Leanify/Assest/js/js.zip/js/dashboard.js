document.addEventListener('DOMContentLoaded', function () {
    const body = document.querySelector("body"),
        modeToggle = body.querySelector(".mode-toggle"),
        sidebar = body.querySelector("nav"),
        sidebarToggle = body.querySelector(".sidebar-toggle"),
        cardElements = body.querySelectorAll(".card"),
        cardElements2 = body.querySelectorAll(".modal-content");

    let getMode = localStorage.getItem("mode");
    if (getMode && getMode === "dark") {
        body.classList.add("dark");
        cardElements.forEach(function (card) {
            card.classList.add("darkmode");
        });
        cardElements2.forEach(function (card2) {
            card2.classList.add("darkmode");
        });
    }

    let getStatus = localStorage.getItem("status");
    if (getStatus && getStatus === "close") {
        sidebar.classList.add("close");
    }

    modeToggle.addEventListener("click", () => {
        body.classList.toggle("dark");
        cardElements.forEach(function (card) {
            card.classList.toggle("darkmode");
        });
        cardElements2.forEach(function (card2) {
            card2.classList.toggle("darkmode");
        });
        if (body.classList.contains("dark")) {
            localStorage.setItem("mode", "dark");
        } else {
            localStorage.setItem("mode", "light");
        }
    });

    sidebarToggle.addEventListener("click", () => {
        sidebar.classList.toggle("close");
        if (sidebar.classList.contains("close")) {
            localStorage.setItem("status", "close");
        } else {
            localStorage.setItem("status", "open");
        }
    });
});